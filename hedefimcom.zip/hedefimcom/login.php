<?php
session_start();

// Eğer kullanıcı zaten giriş yapmışsa, ana sayfaya yönlendir
if (isset($_SESSION['kullanici_adi'])) {
    header("Location: index.php");
    exit;
}

// Veritabanı bağlantısı
$host = "localhost";
$dbname = "yemek_tarifi";
$username = "root";
$password = "";

$conn = new mysqli($host, $username, $password, $dbname);

// Bağlantı hatası kontrolü
if ($conn->connect_error) {
    die("Veritabanı bağlantısı başarısız: " . $conn->connect_error);
}

// Giriş yapma işlemi
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Kullanıcıyı veritabanında ara
    $sql = "SELECT sifre, role, is_verified FROM kullanicilar WHERE kullanici_adi = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $hashed_password = $row['sifre'];
        $role = $row['role'];
        $is_verified = $row['is_verified'];

        // Kullanıcı doğrulandı mı kontrolü
        if ($is_verified == 0) {
            echo "<p class='error'>Hesabınız doğrulanmamış. Lütfen e-postanızı kontrol edin.</p>";
            header("Location: verify.php");
        } else {
            // Şifreyi doğrula
            if (password_verify($password, $hashed_password)) {
                $_SESSION['kullanici_adi'] = $username;
                $_SESSION['role'] = $role;

                // Hoş geldiniz mesajı ve yönlendirme
                echo "<script>alert('Hoş geldiniz, $username!'); window.location.href = 'index.php';</script>";
                exit;
            } else {
                echo "<p class='error'>Hatalı kullanıcı adı veya şifre.</p>";
            }
        }
    } else {
        echo "<p class='error'>Hatalı kullanıcı adı veya şifre.</p>";
    }

    $stmt->close();
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Giriş Yap</title>
    <link rel="stylesheet" href="login.css">
    <script>
        // Şifreyi göster/gizle işlevi
        function togglePassword() {
            var passwordField = document.getElementById("password");
            var passwordType = passwordField.type;
            var toggleIcon = document.getElementById("toggle-icon");

            if (passwordType === "password") {
                passwordField.type = "text";
                toggleIcon.innerHTML = "gizle";
            } else {
                passwordField.type = "password";
                toggleIcon.innerHTML = "göster";
            }
        }
    </script>
</head>
<body>
    <div class="form-container">
        <h1>Giriş Yap</h1>
        <form method="POST" action="login.php">
            <label for="username">Kullanıcı Adı:</label>
            <input type="text" name="username" id="username" placeholder="Kullanıcı adınızı girin" required>
            
            <label for="password">Şifre:</label>
            <div class="password-container">
                <input type="password" name="password" id="password" placeholder="Şifrenizi girin" required>
                <button type="button" id="toggle-button" class="toggle-password" onclick="togglePassword()">
                    <span id="toggle-icon">göster</span>
                </button>  
            </div>
            
            <button type="submit" class="submit-button">Giriş Yap</button>
        </form>
        <p><a href="reset_password.php">Şifremi Unuttum</a></p>
        <p>Hesabınız yok mu? <a href="register.php">Kayıt olun</a></p>
    </div>
</body>
</html>
