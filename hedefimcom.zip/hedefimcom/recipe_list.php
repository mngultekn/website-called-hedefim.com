<?php
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] == 'user') {
    header("Location: index.php");
    exit;
}

$host = "localhost";
$dbname = "yemek_tarifi";
$username = "root";
$password = "";
$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Veritabanı bağlantısı başarısız: " . $conn->connect_error);
}

$selectlist = "SELECT * FROM tarifler";
$resultlist = $conn->query($selectlist);

?>
<!DOCTYPE html>
<html lang="tr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mektup Listesi</title>
    <link rel="stylesheet" href="recipe_list.css">
    <script>
    function confirmDelete() {
        return confirm("Bu mektubu silmek istediğinizden emin misiniz?");
    }
    </script>
</head>

<body>
    <nav>
        <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
        <a href="index.php">Ana Sayfa</a>
        <a href="new_recipe.php">Mektup Ekle</a>
        <a href="user_list.php">Kullanıcı Listesi</a>
        <a href="logout.php">Çıkış yap</a>
        <?php else: ?>
        <a href="index.php">Ana Sayfa</a>
        <a href="new_recipe.php">Mektup Ekle</a>
        <a href="logout.php">Çıkış yap</a>
        <?php endif; ?>
    </nav>
    <?php
    if ($resultlist->num_rows > 0) {
        echo "<dl>";
        while ($picklist = $resultlist->fetch_assoc()) {
            $id = $picklist["id"];
            $title = $picklist["title"];
            $description = $picklist["description"];
            $ingredients = $picklist["ingredients"];
            $instructions = $picklist["instructions"];
            
            echo "<dt>ID: $id</dt>";
            echo "<dd><strong>Başlık:</strong> $title</dd>";
            echo "<dd><strong>Açıklama:</strong> $description</dd>";
            echo "<dd><strong>Malzemeler:</strong> $ingredients</dd>";
            echo "<dd><strong>Yapılışı:</strong> $instructions</dd>";
            echo "<dd>";
            echo "<a href='delete_recipe.php?id=$id' onclick='return confirmDelete();'><button>Sil</button></a> ";
            echo "<a href='edit_recipe.php?id=$id'><button>Düzenle</button></a>";
            echo "</dd>";
            echo "<hr>";
        }
        echo "</dl>";
    } else {
        echo "Henüz Mektup Bulunmamaktadır!";
    }
    ?>
</body>

</html>