<?php
session_start();

// Veritabanı bağlantısı
$host = "localhost";
$dbname = "yemek_tarifi";
$username = "root";
$password = "";

$conn = new mysqli($host, $username, $password, $dbname);

// Bağlantı hatası kontrolü
if ($conn->connect_error) {
    die("Veritabanı bağlantısı başarısız: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['new_password']) && isset($_POST['confirm_password']) && !empty($_POST['new_password']) && !empty($_POST['confirm_password'])) {
        $email = $_SESSION['reset_email'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];

        // Şifreler eşleşiyor mu kontrol et
        if ($new_password === $confirm_password) {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

            // Yeni şifreyi kaydet
            $sql = "UPDATE kullanicilar SET sifre = ?, reset_code = NULL, reset_time = NULL WHERE email = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ss", $hashed_password, $email);

            if ($stmt->execute()) {
                echo "<p>Şifreniz başarıyla değiştirildi! Şimdi giriş yapabilirsiniz.</p>";
                session_unset();
                session_destroy();
                header("Location: login.php"); // Giriş sayfasına yönlendir
                exit();
            } else {
                echo "<p>Şifre değiştirme işlemi sırasında bir hata oluştu.</p>";
            }
        } else {
            echo "<p>Şifreler eşleşmiyor. Lütfen her iki şifreyi de doğru girin.</p>";
        }

        $stmt->close();
    } else {
        echo "<p>Lütfen tüm alanları doldurduğunuzdan emin olun.</p>";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Yeni Şifre</title>
    <link rel="stylesheet" href="new_password.css">
</head>
<body>
    <div class="form-container">
        <h1>Yeni Şifre Belirleme</h1>
        <form method="POST" action="new_password.php">
            <label for="new_password">Yeni Şifre:</label>
            <input type="password" name="new_password" id="new_password" placeholder="Yeni şifrenizi girin" required>
            
            <label for="confirm_password">Yeni Şifreyi Onayla:</label>
            <input type="password" name="confirm_password" id="confirm_password" placeholder="Yeni şifrenizi tekrar girin" required>
            
            <button type="submit">Şifreyi Değiştir</button>
        </form>
    </div>
</body>
</html>
