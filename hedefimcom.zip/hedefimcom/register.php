<?php
session_start();

// Veritabanı bağlantısı
$host = "localhost";
$dbname = "yemek_tarifi";
$username = "root";
$password = "";

$conn = new mysqli($host, $username, $password, $dbname);

// Bağlantı hatası kontrolü
if ($conn->connect_error) {
    die("Veritabanı bağlantısı başarısız: " . $conn->connect_error);
}

// PHPMailer'ı dahil et
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php'; // Composer ile kurduysanız

// Kayıt işlemi
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $email = $_POST['email']; // E-posta adresini alıyoruz

    // Şifreyi hashle
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Kullanıcı adı zaten var mı kontrolü
    $sql = "SELECT * FROM kullanicilar WHERE kullanici_adi = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo "<p>Bu kullanıcı adı zaten alınmış.</p>";
    } else {
        // E-posta adresi zaten var mı kontrolü
        $sql_email = "SELECT * FROM kullanicilar WHERE email = ?";
        $stmt_email = $conn->prepare($sql_email);
        $stmt_email->bind_param("s", $email);
        $stmt_email->execute();
        $result_email = $stmt_email->get_result();

        if ($result_email->num_rows > 0) {
            echo "<p>Bu e-posta adresi zaten kullanımda. Lütfen başka bir e-posta adresi girin.</p>";
        } else {
            // Kullanıcı kaydını veritabanına ekle
            $verification_code = rand(100000, 999999); // 6 haneli doğrulama kodu
            $sql_insert = "INSERT INTO kullanicilar (kullanici_adi, sifre, email, verification_code) VALUES (?, ?, ?, ?)";
            $stmt_insert = $conn->prepare($sql_insert);
            $stmt_insert->bind_param("ssss", $username, $hashed_password, $email, $verification_code);

            if ($stmt_insert->execute()) {
                // Kullanıcının e-posta adresini session'a kaydet
                $_SESSION['email'] = $email;

                // PHPMailer ile doğrulama e-postası gönderme
                $mail = new PHPMailer(true);
                try {
                    // Sunucu ayarları
                    $mail->isSMTP();
                    $mail->Host = 'smtp.gmail.com'; // SMTP sunucu adresi
                    $mail->SMTPAuth = true;
                    $mail->Username = 'dasssakebabl@gmail.com'; // Gmail e-posta adresiniz
                    $mail->Password = 'kqvm tsyf hlkz yono'; // Gmail şifreniz veya uygulama şifresi
                    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                    $mail->Port = 587;

                    // Alıcı ve gönderici ayarları
                    $mail->setFrom('your-email@gmail.com', 'hedefim.com Web Sitesi');
                    $mail->addAddress($email); // Kullanıcının e-posta adresi

                    // Doğrulama linki
                    $verification_url = "http://localhost/yemek-tarifi/verify.php";

                    // E-posta içeriği
                    $mail->isHTML(true);
                    $mail->Subject = 'E-posta Dogrulama Kodu';
                    $mail->Body = "Merhaba, e-posta doğrulamanız için kodunuz: <strong>$verification_code</strong><br>
                                   Doğrulamak için bu linki tıklayın: <a href='$verification_url'>$verification_url</a>";

                    $mail->send();
                } catch (Exception $e) {
                    echo "E-posta gönderilemedi. Hata: {$mail->ErrorInfo}";
                }

                // Kullanıcıyı verify.php sayfasına yönlendir
                header("Location: verify.php");
                exit; // Yönlendirme sonrası kod çalışmasını durdur
            } else {
                echo "<p>Kayıt işlemi başarısız oldu. Lütfen tekrar deneyin.</p>";
            }
        }

        $stmt_email->close();
    }

    $stmt->close();
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="tr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hesap Oluştur</title>
    <link rel="stylesheet" href="register.css">
    <script>
    // Şifreyi göster/gizle işlevi
    function togglePassword() {
        var passwordField = document.getElementById("password");
        var passwordType = passwordField.type;
        var toggleIcon = document.getElementById("toggle-icon");

        if (passwordType === "password") {
            passwordField.type = "text";
            toggleIcon.innerHTML = "gizle";
        } else {
            passwordField.type = "password";
            toggleIcon.innerHTML = "göster";
        }
    }
    </script>
</head>

<body>
    <div class="form-container">
        <h1>Hesap Oluştur</h1>
        <form method="POST" action="register.php">
            <label for="username">Kullanıcı Adı:</label>
            <input type="text" name="username" id="username" placeholder="Kullanıcı adınızı girin" required>

            <label for="email">E-posta Adresi:</label>
            <input type="email" name="email" id="email" placeholder="E-posta adresinizi girin" required>

            <label for="password">Şifre:</label>
            <div class="password-container">
                <input type="password" name="password" id="password" placeholder="Şifrenizi girin" required>
                <button type="button" id="toggle-button" class="toggle-password" onclick="togglePassword()">
                    <span id="toggle-icon">göster</span>
                </button>
            </div>

            <button type="submit" class="submit-button">Kayıt Ol</button>
        </form>
        <p>Zaten hesabınız var mı? <a href="login.php">Giriş yapın</a></p>
    </div>
</body>

</html>