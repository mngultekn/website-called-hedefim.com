<?php
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}

$host = "localhost";
$dbname = "yemek_tarifi";
$username = "root";
$password = "";
$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Veritabanı bağlantısı başarısız: " . $conn->connect_error);
}

// Rol değiştirme işlemi
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_role'])) {
    $id = intval($_POST['user_id']);
    $new_role = $conn->real_escape_string($_POST['role']);
    
    $valid_roles = ['user', 'mod', 'admin']; // Geçerli roller
    if (in_array($new_role, $valid_roles)) {
        $sql = "UPDATE kullanicilar SET role = '$new_role' WHERE id = $id";
        if ($conn->query($sql) === TRUE) {
            echo "<p style='color: green;'>Rol başarıyla güncellendi!</p>";
        } else {
            echo "<p style='color: red;'>Güncelleme sırasında hata oluştu: " . $conn->error . "</p>";
        }
    } else {
        echo "<p style='color: red;'>Geçersiz rol seçimi!</p>";
    }
}

// Kullanıcı silme işlemi
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_user'])) {
    $id = intval($_POST['user_id']);
    $sql = "DELETE FROM kullanicilar WHERE id = $id";
    if ($conn->query($sql) === TRUE) {
        echo "<p style='color: green;'>Kullanıcı başarıyla silindi!</p>";
    } else {
        echo "<p style='color: red;'>Silme işlemi sırasında hata oluştu: " . $conn->error . "</p>";
    }
}

// Kullanıcıları listeleme
$selectlist = "SELECT * FROM kullanicilar";
$resultlist = $conn->query($selectlist);
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kullanıcı Listesi</title>
    <link rel="stylesheet" href="user_list.css">
</head>
<body>
    <nav>
        <a href="index.php">Ana Sayfa</a>
        <a href="new_recipe.php">Mektup Ekle</a>
        <a href="recipe_list.php">Mektup Listesi</a>
        <a href="logout.php">Çıkış yap</a>
    </nav>

    <h1>Kullanıcı Listesi</h1>
    <?php if ($resultlist->num_rows > 0): ?>
        <table border="1" style="width: 80%; margin: 20px auto; text-align: left; border-collapse: collapse;">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Kullanıcı Adı</th>
                    <th>E-posta</th>
                    <th>Oluşturulma Tarihi</th>
                    <th>Rol</th>
                    <th>İşlemler</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $resultlist->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo htmlspecialchars($row['kullanici_adi']); ?></td>
                        <td><?php echo htmlspecialchars($row['email']); ?></td>
                        <td><?php echo $row['created_at']; ?></td>
                        <td><?php echo $row['role']; ?></td>
                        <td>
                            <!-- Rol Güncelleme -->
                            <form method="POST" action="" style="display: inline-block;">
                                <input type="hidden" name="user_id" value="<?php echo $row['id']; ?>">
                                <select name="role" required>
                                    <option value="user" <?php echo $row['role'] === 'user' ? 'selected' : ''; ?>>User</option>
                                    <option value="mod" <?php echo $row['role'] === 'mod' ? 'selected' : ''; ?>>Mod</option>
                                    <option value="admin" <?php echo $row['role'] === 'admin' ? 'selected' : ''; ?>>Admin</option>
                                </select>
                                <button type="submit" name="update_role">Güncelle</button>
                            </form>
                            <!-- Kullanıcı Silme -->
                            <form method="POST" action="" style="display: inline-block;">
                                <input type="hidden" name="user_id" value="<?php echo $row['id']; ?>">
                                <button type="submit" name="delete_user" onclick="return confirm('Bu kullanıcıyı silmek istediğinizden emin misiniz?');">Sil</button>
                            </form>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>Henüz Kullanıcı Bulunmamaktadır!</p>
    <?php endif; ?>
</body>
</html>
