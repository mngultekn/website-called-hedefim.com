<?php
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] == 'user') {
    header("Location: index.php");
    exit;
}

$host = "localhost";
$dbname = "yemek_tarifi";
$username = "root";
$password = "";
$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Veritabanı bağlantısı başarısız: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $ingredients = $_POST['ingredients'];
    $instructions = $_POST['instructions'];

    $image = "";
    if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
        $image = $_FILES['image']['name'];
        $image_tmp = $_FILES['image']['tmp_name'];
        $image_path = "images/" . $image;
        
        move_uploaded_file($image_tmp, $image_path);
    }
    
    $sql = "INSERT INTO tarifler (title, description, ingredients, instructions, image) 
            VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssss", $title, $description, $ingredients, $instructions, $image);
    
    if ($stmt->execute()) {
        echo "<p class='success'>Mektup başarıyla eklendi!</p>";
    } else {
        echo "<p class='error'>Mektup eklenirken bir hata oluştu.</p>";
    }
    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="tr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mektup Ekle</title>
    <link rel="stylesheet" href="new_recipe.css">
</head>

<body>
    <header>
        <nav>
            <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
            <a href="index.php">Ana Sayfa</a>
            <a href="user_list.php">Kullanıcı Listesi</a>
            <a href="recipe_list.php">Mektup Listesi</a>
            <a href="logout.php">Çıkış yap</a>
            <?php else: ?>
            <a href="index.php">Ana Sayfa</a>
            <a href="recipe_list.php">Mektup Listesi</a>
            <a href="logout.php">Çıkış yap</a>
            <?php endif; ?>
        </nav>
    </header>

    <main>
        <h1>Yeni Mektup Ekle</h1>
        <form action="new_recipe.php" method="POST" enctype="multipart/form-data" class="form-container">
            <label for="title">Başlık:</label>
            <input type="text" name="title" id="title" required>

            <label for="description"> </label>
            <textarea name="description" id="description" required></textarea>

            <!-- <label for="ingredients">Malzemeler (Virgülle ayırın):</label>
            <textarea name="ingredients" id="ingredients" required></textarea>

            <label for="instructions">Yapılış:</label>
            <textarea name="instructions" id="instructions" required></textarea> -->

            <label for="image">Görsel:</label>
            <input type="file" name="image" id="image" accept="image/*">

            <button type="submit">Mektup Ekle</button>
        </form>
    </main>
</body>

</html>