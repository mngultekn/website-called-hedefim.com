<?php
session_start();

// Veritabanı bağlantısı
$host = "localhost";
$dbname = "yemek_tarifi";
$username = "root";
$password = "";

$conn = new mysqli($host, $username, $password, $dbname);

// Bağlantı hatası kontrolü
if ($conn->connect_error) {
    die("Veritabanı bağlantısı başarısız: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_SESSION['reset_email'];
    $verification_code = $_POST['verification_code'];

    // Doğrulama kodunu kontrol et
    $sql = "SELECT * FROM kullanicilar WHERE email = ? AND reset_code = ? AND reset_time > (NOW() - INTERVAL 30 MINUTE)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $email, $verification_code);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $_SESSION['reset_step'] = 3; // Şifre belirleme aşamasına geç
        header("Location: new_password.php"); // Yeni şifre sayfasına yönlendir
    } else {
        echo "<p>Geçersiz veya süresi dolmuş doğrulama kodu.</p>";
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doğrulama Kodu</title>
    <link rel="stylesheet" href="verify_password.css">
</head>
<body>
    <div class="form-container">
        <h1>Doğrulama Kodu</h1>
        <form method="POST" action="verify_password.php">
            <label for="verification_code">Doğrulama Kodu:</label>
            <input type="text" name="verification_code" id="verification_code" placeholder="E-postanızdaki kodu girin" required>
            <button type="submit">Doğrula</button>
        </form>
    </div>
</body>
</html>
