<?php
session_start();

// Veritabanı bağlantısı
$host = "localhost";
$dbname = "yemek_tarifi";
$username = "root";
$password = "";

$conn = new mysqli($host, $username, $password, $dbname);

// Bağlantı hatası kontrolü
if ($conn->connect_error) {
    die("Veritabanı bağlantısı başarısız: " . $conn->connect_error);
}

// PHPMailer'ı dahil et
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'vendor/autoload.php';

// Aşama kontrolü
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];

    // Kullanıcıyı veritabanında ara
    $sql = "SELECT * FROM kullanicilar WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Doğrulama kodu oluştur
        $verification_code = rand(100000, 999999);

        // Kod ve zamanı veritabanına kaydet
        $sql_update = "UPDATE kullanicilar SET reset_code = ?, reset_time = NOW() WHERE email = ?";
        $stmt_update = $conn->prepare($sql_update);
        $stmt_update->bind_param("is", $verification_code, $email);
        $stmt_update->execute();

        // PHPMailer ile e-posta gönder
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'dasssakebabl@gmail.com'; // Geliştirme amaçlı e-posta adresi
            $mail->Password = 'kqvm tsyf hlkz yono'; // E-posta şifreniz
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            $mail->setFrom('your-email@gmail.com', 'hedefim.com Web Sitesi');
            $mail->addAddress($email);

            $mail->isHTML(true);
            $mail->Subject = 'Sifre Sifirlama Kodu';
            $mail->Body = 'Sifre sifirlama kodunuz: ' . $verification_code;

            $mail->send();
            echo "<p>Sifre sifirlama kodu e-posta adresinize gönderildi!</p>";
            $_SESSION['reset_email'] = $email;
            header("Location: verify_password.php"); // Doğrulama sayfasına yönlendir
        } catch (Exception $e) {
            echo "E-posta gönderilemedi. Hata: {$mail->ErrorInfo}";
        }
    } else {
        echo "<p>Böyle bir e-posta adresi kayıtlı değil.</p>";
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Şifre Sıfırlama</title>
    <link rel="stylesheet" href="reset_password.css">
</head>
<body>
    <div class="form-container">
        <h1>Şifre Sıfırlama</h1>
        <form method="POST" action="reset_password.php">
            <label for="email">E-posta Adresi:</label>
            <input type="email" name="email" id="email" placeholder="Kayıtlı e-posta adresinizi girin" required>
            <button type="submit">Kod Gönder</button>
        </form>
    </div>
</body>
</html>
