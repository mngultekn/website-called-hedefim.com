<?php
if (!isset($_GET['id'])) {
    die("Geçersiz istek!");
}

$host = "localhost";
$dbname = "yemek_tarifi";
$username = "root";
$password = "";
$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Veritabanı bağlantısı başarısız: " . $conn->connect_error);
}

$id = intval($_GET['id']);
$sql = "DELETE FROM tarifler WHERE id = $id";

if ($conn->query($sql) === TRUE) {
    echo "Mektup başarıyla silindi!";
    header("Location: recipe_list.php");
    exit;
} else {
    echo "Hata: " . $conn->error;
}
$conn->close();
?>
