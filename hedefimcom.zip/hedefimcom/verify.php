<?php
session_start();

// Veritabanı bağlantısı
$host = "localhost";
$dbname = "yemek_tarifi";
$username = "root";
$password = "";

$conn = new mysqli($host, $username, $password, $dbname);

// Bağlantı hatası kontrolü
if ($conn->connect_error) {
    die("Veritabanı bağlantısı başarısız: " . $conn->connect_error);
}

// Doğrulama işlemi
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $verification_code = $_POST['verification_code'];

    // Veritabanında e-posta ve kod eşleşmesini kontrol et
    $sql = "SELECT * FROM kullanicilar WHERE email = ? AND verification_code = ? AND is_verified = 0";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $email, $verification_code);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Doğrulama başarılı, hesabı aktif hale getir
        $sql_update = "UPDATE kullanicilar SET is_verified = 1 WHERE email = ?";
        $stmt_update = $conn->prepare($sql_update);
        $stmt_update->bind_param("s", $email);

        if ($stmt_update->execute()) {
            // Doğrulama başarılı, login.php'ye yönlendir
            $_SESSION['message'] = "Doğrulama başarılı! Şimdi giriş yapabilirsiniz.";
            header("Location: login.php");
            exit; // Yönlendirmeden sonra script çalışmaya devam etmesin
        } else {
            $error = "Doğrulama işlemi sırasında bir hata oluştu. Lütfen tekrar deneyin.";
        }
        $stmt_update->close();
    } else {
        $error = "Geçersiz doğrulama kodu veya e-posta adresi.";
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-posta Doğrulama</title>
    <link rel="stylesheet" href="verify.css">
</head>
<body>
    <div class="form-container">
        <h1>E-posta Doğrulama</h1>
        <?php if (isset($error)) { echo "<p style='color: red;'>$error</p>"; } ?>
        <form method="POST" action="verify.php">
            <label for="email">E-posta Adresi:</label>
            <input type="email" name="email" id="email" placeholder="Kayıtlı e-posta adresinizi girin" required>
            
            <label for="verification_code">Doğrulama Kodu:</label>
            <input type="text" name="verification_code" id="verification_code" placeholder="E-postanızdaki kodu girin" required>
            
            <button type="submit" class="submit-button">Doğrula</button>
        </form>
        <p>Kod içeren bir e-posta almadınız mı? <a href="resend.php">Tekrar gönder</a></p>
    </div>
</body>
</html>
