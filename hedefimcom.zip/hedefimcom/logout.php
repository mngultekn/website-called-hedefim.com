<?php
session_start();

if (isset($_GET['confirm']) && $_GET['confirm'] == 'yes') {
    session_unset();
    session_destroy();
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Çıkış Yapıldı</title>
    <link rel="stylesheet" href="logout.css">
    <script>
        function confirmLogout() {
            var result = confirm("Çıkış yapmak istediğinize emin misiniz?");
            if (result) {
                // Kullanıcı "Evet" dediğinde, çıkış işlemi için 'confirm=yes' parametresi ile sayfayı yeniden yükle
                window.location.href = "logout.php?confirm=yes"; // Onay verildi, çıkış yapılacak
            } else {
                window.location.href = "index.php";
            }
        }
    </script>
</head>
<body>

    <div class="form-container">
        <h1>Çıkış Yap</h1>
        <p>Çıkış yapmak üzereydiniz. Çıkış yapmak istediğinize emin misiniz?</p>
        <button class="logout-btn" onclick="confirmLogout()">Evet, çıkış yap</button>
        <button class="cancel-btn" onclick="window.location.href='index.php'">Hayır, geri dön</button>
    </div>

</body>
</html>
