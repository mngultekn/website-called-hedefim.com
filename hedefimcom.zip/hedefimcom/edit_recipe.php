<?php
$host = "localhost";
$dbname = "yemek_tarifi";
$username = "root";
$password = "";

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Veritabanı bağlantısı başarısız: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (!isset($_GET['id']) || empty($_GET['id'])) {
        die("Geçersiz istek! 'id' parametresi bulunamadı.");
    }

    $id = intval($_GET['id']);
    $sql = "SELECT * FROM tarifler WHERE id = $id";
    $result = $conn->query($sql);

    if ($result->num_rows === 1) {
        $tarif = $result->fetch_assoc();
    } else {
        die("Tarif bulunamadı!");
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update'])) {
    $id = intval($_POST['id']);
    $title = $conn->real_escape_string($_POST['title']);
    $description = $conn->real_escape_string($_POST['description']);
    $ingredients = $conn->real_escape_string($_POST['ingredients']);
    $instructions = $conn->real_escape_string($_POST['instructions']);

    $sql = "UPDATE tarifler SET 
                title = '$title', 
                description = '$description', 
                ingredients = '$ingredients', 
                instructions = '$instructions' 
            WHERE id = $id";

    if ($conn->query($sql) === TRUE) {
        header("Location: recipe_list.php");
        exit;
    } else {
        echo "Güncelleme sırasında hata oluştu: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="tr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mektup Düzenle</title>
    <link rel="stylesheet" href="edit_recipe.css">
</head>

<body>
    <h1>Mektup Düzenle</h1>
    <form method="post" action="edit_recipe.php">
        <input type="hidden" name="id" value="<?php echo $tarif['id']; ?>">

        <label for="title">Başlık:</label><br>
        <input type="text" id="title" name="title" value="<?php echo $tarif['title']; ?>" required><br><br>

        <label for="description">Açıklama:</label><br>
        <textarea id="description" name="description" rows="4" cols="50"
            required><?php echo $tarif['description']; ?></textarea><br><br>

        <!-- <label for="ingredients">Malzemeler:</label><br>
        <textarea id="ingredients" name="ingredients" rows="4" cols="50" required><?php echo $tarif['ingredients']; ?></textarea><br><br>

        <label for="instructions">Talimatlar:</label><br>
        <textarea id="instructions" name="instructions" rows="4" cols="50" required><?php echo $tarif['instructions']; ?></textarea><br><br> -->

        <button type="submit" name="update">Güncelle</button>
    </form>
</body>

</html>