<?php
if (!isset($_GET['id'])) {
    die("Geçersiz istek!");
}

$host = "localhost";
$dbname = "yemek_tarifi";
$username = "root";
$password = "";
$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Veritabanı bağlantısı başarısız: " . $conn->connect_error);
}

$id = intval($_GET['id']);
$sql = "DELETE FROM kullanicilar WHERE id = $id";

if ($conn->query($sql) === TRUE) {
    echo "Kullanıcı başarıyla silindi!";
    header("Location: user_list.php");
    exit;
} else {
    echo "Hata: " . $conn->error;
}
$conn->close();
?>
