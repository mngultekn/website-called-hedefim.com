<?php
session_start(); 

if (!isset($_SESSION['kullanici_adi'])) {
    header("Location: login.php"); 
    exit;
}

if (isset($_GET['id'])) {
    $recipe_id = $_GET['id'];
} else {
    header("Location: index.php");
    exit;
}

$host = "localhost";
$dbname = "yemek_tarifi";
$username = "root";
$password = "";

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Veritabanı bağlantısı başarısız: " . $conn->connect_error);
}

$sql = "SELECT * FROM tarifler WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $recipe_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $recipe = $result->fetch_assoc();
} else {
    
    header("Location: index.php");
    exit;
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="tr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $recipe['title']; ?> Mektubu</title>
    <link rel="stylesheet" href="recipe.css">
</head>

<body>

    <header>
        <nav>
            <?php if (isset($_SESSION['kullanici_adi']) && $_SESSION['role'] === 'user'): ?>
            <a href="index.php">Ana Sayfa</a>
            <a href="logout.php">Çıkış Yap</a>
            <?php elseif (isset($_SESSION['role']) && $_SESSION['role'] === 'mod'): ?>
            <a href="index.php">Ana Sayfa</a>
            <a href="new_recipe.php">Mektup Ekle</a>
            <a href="recipe_list.php">Mektup Listesi</a>
            <a href="logout.php">Çıkış yap</a>
            <?php elseif (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
            <a href="index.php">Ana Sayfa</a>
            <a href="new_recipe.php">Mektup Ekle</a>
            <a href="recipe_list.php">Mektup Listesi</a>
            <a href="user_list.php">Kullanıcı Listesi</a>
            <a href="logout.php">Çıkış yap</a>
            <?php else: ?>
            <a href="register.php">Kayıt Ol</a>
            <a href="login.php">Giriş Yap</a>
            <?php endif; ?>
        </nav>
    </header>

    <main>
        <div class="recipe-detail">
            <center>
                <h2>Mektup</h2>
                <img src="images/<?php echo $recipe['image']; ?>" alt="<?php echo $recipe['title']; ?>"
                    class="recipe-image">
                <p><strong> </strong> <?php echo $recipe['description']; ?></p>
                <!-- <h3>Malzemeler:</h3>
            <div class="ingredients">
                <?php
                $ingredients = explode(",", $recipe['ingredients']); 
                $ingredients_display = implode(", ", array_map('trim', $ingredients)); 
                echo "<span class='ingredient'>" . htmlspecialchars($ingredients_display) . "</span>"; 
                ?>
            </div>
            <h3>Yapılışı:</h3>
            <p><?php echo nl2br(htmlspecialchars($recipe['instructions'])); ?></p> -->
            </center>
        </div>
    </main>

    <footer>
        <p>&copy;2024 <a href="mngultekn.com" style="color: white
        " target="_blank"> Hedefim</a> Her hakkı saklıdır.
        </p>
    </footer>

</body>

</html>