-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 09 Oca 2025, 20:37:21
-- Sunucu sürümü: 10.4.32-MariaDB
-- PHP Sürümü: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `yemek_tarifi`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kullanicilar`
--

CREATE TABLE `kullanicilar` (
  `id` int(11) NOT NULL,
  `kullanici_adi` varchar(255) NOT NULL,
  `sifre` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `verification_code` varchar(6) NOT NULL,
  `is_verified` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `role` enum('user','mod','admin') NOT NULL DEFAULT 'user',
  `reset_code` int(11) DEFAULT NULL,
  `reset_time` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `kullanicilar`
--

INSERT INTO `kullanicilar` (`id`, `kullanici_adi`, `sifre`, `email`, `verification_code`, `is_verified`, `created_at`, `role`, `reset_code`, `reset_time`) VALUES
(6, 'muhammed1', '$2y$10$NgyC2Af5i5CSSJNFCuB.r.zTD5BK7s8AtFXCLiVCLicn3rvI1mILC', 'mng869964@gmail.com', '952435', 1, '2025-01-07 15:43:44', 'user', NULL, NULL),
(7, 'mngultekn', '$2y$10$1cqo.F8UPRWZ7ZuQRHKOLORQWfbM2K9DrC3T1GCj3M/cyy/R1Ujja', 'mngultekn@gmail.com', '119574', 1, '2025-01-07 16:30:28', 'admin', NULL, NULL),
(8, 'falanfilan', '$2y$10$5NsZdZlbXQHkKcHeGe196OqxKZatzzie/PlCPhuiro1rFxlBeZ8Qy', 'mehmetaliuslu1@gmail.com', '908270', 0, '2025-01-08 16:56:06', 'user', NULL, NULL);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `tarifler`
--

CREATE TABLE `tarifler` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `ingredients` text DEFAULT NULL,
  `instructions` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `tarifler`
--

INSERT INTO `tarifler` (`id`, `title`, `description`, `ingredients`, `instructions`, `image`, `created_at`) VALUES
(4, 'KENDİNE İNAN VE HAREKETE GEÇ!', 'Sevgili Dostum,\r\n\r\nHayat bazen bizim için zorlaşabilir, önümüze çıkan engeller büyüyebilir ve yolun sonu belirsiz görünebilir. Ancak unutma, bu anlar aynı zamanda senin kim olduğunu ve neler başarabileceğini gösteren fırsatlardır. Bugün bu mektubu yazıyorum, çünkü senin içindeki potansiyeli biliyorum ve seni yüreklendirmek istiyorum.\r\n\r\nHedeflerine ulaşmak için çıktığın bu yolda öncelikle kendine inanman gerekiyor. İnanç, bir yolculuğun başlangıcıdır. Kendine duyduğun güven, seni güçlü kılacak ve seni daha önce hayal bile edemediğin yerlere taşıyacaktır. Unutma ki herkesin bir hikayesi var ve her başarı hikayesi, zorluklarla, başarısızlıklarla ve yeniden ayağa kalkma cesaretiyle doludur. Bugün karşılaştığın her zorluk, yarın için seni daha güçlü bir insan yapacak.\r\n\r\nMotivasyon, yalnızca bir duygu değil, bir eylemdir. Hayatında yapmak istediğin değişiklikler için harekete geçmen gerekiyor. Küçük adımlarla başla. Her gün, seni hedeflerine bir adım daha yaklaştıracak bir şey yap. Bu küçük adımlar, bir süre sonra büyük bir değişim yaratacak. Eğer her şey bir anda mükemmel olsaydı, çabalarının kıymetini bilebilir miydin? Belki de en büyük ödül, hedefe ulaştıktan sonra değil, o hedefe giden yolda öğrendiğin şeylerde gizlidir.\r\n\r\nUnutma, başarısızlık korkusu seni durdurmasın. Başarısızlık, öğrenmenin ve büyümenin doğal bir parçasıdır. Dünyanın en başarılı insanları bile hayatlarının bir noktasında başarısız olmuştur. Onları farklı kılan şey, vazgeçmemeleri ve her seferinde yeniden denemeleridir. Thomas Edison\'un dediği gibi, \"Başarısız olmadım, işe yaramayan 10.000 yol buldum.\" Sen de her başarısızlığı bir öğrenme fırsatı olarak gör ve yoluna devam et.\r\n\r\nBir diğer önemli konu, hedeflerine ulaşırken sabırlı olman gerektiğidir. Hemen her şeyin elimizin altında olduğu bir dünyada sabretmek zor olabilir, ancak gerçekten değerli olan hiçbir şey kolayca elde edilmez. Emek vermek, zaman ayırmak ve çaba göstermek gerekiyor. Sabır, azimle birleştiğinde, önünde hiçbir şey duramaz.\r\n\r\nKendini motive etmek için ilham kaynakları bul. Bu bir kitap, bir şarkı, bir film ya da hayatını örnek aldığın bir insan olabilir. İlham aldığın şeyler seni yeniden şarj edecek ve enerjini tazeleyecektir. Ayrıca, çevrendeki insanlara dikkat et. Seni destekleyen, cesaretlendiren ve olumlu bir enerji yayan insanlarla zaman geçir. Negatif düşünceler seni aşağı çekebilir, bu yüzden pozitif bir çevre oluşturman önemli.\r\n\r\nHedeflerine ulaşma yolunda sadece zihinsel değil, fiziksel sağlığına da dikkat et. Sağlıklı bir beden, güçlü bir zihin için gereklidir. Düzenli egzersiz yap, dengeli beslen ve yeterince dinlen. Kendine iyi bakmak, motivasyonunu ve enerjini yüksek tutmanın bir anahtarıdır.\r\n\r\nSon olarak, unutma ki hayat bir maraton, bir sprint değil. Hedeflerine hemen ulaşamayabilirsin ve bu tamamen normaldir. Kendine nazik ol, süreç boyunca kendi başarılarını kutla ve her yeni günü bir fırsat olarak gör. Çünkü sen buna değersin.\r\n\r\nHer zaman hatırla: İçinde sonsuz bir potansiyel var. Senin inancın ve kararlılığınla, hayal ettiğin her şeyi başarabilirsin. Yolun nereye çıkarsa çıksın, kendine olan güvenin ve çaban seni başarıya götürecektir. Şimdi kalk, harekete geç ve dünyayı kendine hayran bırak!\r\n\r\nSevgilerimizle,\r\n\r\nhedefim.com\r\n\r\n', NULL, NULL, 'hedefim-1.jpg', '2025-01-09 19:24:50'),
(5, 'BAŞARI KARARLILIKLA ATILAN ADIMLARDA GİZLİDİR!..', 'Hedefler, hayatın gerçek anlamını bulmamıza yardımcı olur. Onlar, bizi yönlendiren, zor anlarda bile bize bir hedef doğrultusunda hareket etme gücü veren ışıklardır. Her birimiz, yaşamda farklı hedeflere sahip olabiliriz; kimimiz büyük bir iş kurma hayaliyle yanar, kimimiz kişisel gelişiminde bir adım daha atmayı amaçlar. Fakat hepsinin ortak bir noktası vardır: Bir hedefe ulaşmak için gereken yolculuk başlamakla başlar. Başarı, genellikle bir anda elde edilen bir şey gibi görünse de, gerçekte bir süreçtir. Bu süreç, bazen inişli çıkışlı olabilir. Kimi zaman her şey yolunda gidiyormuş gibi hissedersiniz, kim zaman ise hiçbir şey yolunda gitmez. Ama unutmayın ki başarı, yalnızca o anki başarılardan ibaret değildir; asıl başarı, yol boyunca attığınız kararlı adımlarla gelir. Bazen zorlayıcı günlerde, motivasyonumuzu kaybettiğimizde ya da hedefimize ne kadar yaklaşmış olursak olalım, her şeyin tükendiğini hissettiğimizde, asıl önemli olan şey direncimizi kaybetmeden devam edebilmektir. Yola çıktığınızda, hedefinizin ne kadar büyük olduğuna odaklanmayın. Her büyük başarının küçük ama anlamlı adımlarla başladığını unutmayın. Her şeyin başı, bir adım atmakla başlar. Bir gün o küçük adımlar, sizi hedefinize ulaşmak için gereken noktaya getirecek. Fakat bu noktada, “başarıyı” sadece varış noktası olarak görmemelisiniz. Gerçek başarı, yolculuk boyunca öğrendikleriniz, karşılaştığınız zorluklarla baş etme şekliniz ve her düşüşten sonra yeniden ayağa kalkma gücüdür. İçinizdeki potansiyeli keşfedin. Hepimizin bir gücü, bir yeteneği vardır. Bunu fark etmek ve bu gücü doğru yönde kullanmak, size yalnızca hedeflerinize ulaşma fırsatı sunmakla kalmaz, aynı zamanda içsel bir tatmin de sağlar. Bu süreç, aslında bir keşif yolculuğudur. Kendinizi tanımak, sınırlarınızı zorlamak ve büyümek için her anı bir fırsat olarak görmek gerekir. Şunu asla unutmayın: Her gün bir adım daha atmak, sizi ne kadar zorlu bir yolculukta olursanız olun, hedefinize yaklaştırır. Bugün harekete geçmek, geleceğinizi şekillendirmenin en güçlü yoludur. Hiçbir şey, bugünden daha iyi bir zaman dilimi sunmaz. Ertelemeyi bırakın ve harekete geçin. Çünkü “şimdi” en önemli andır ve hedefe doğru atılacak ilk adımı atmak için en doğru zamandır. Korkularınızı geride bırakın, belirsizlikleri kucaklayın ve yolunuzu aydınlatacak kararlılıkla ilerleyin. Bir gün geriye dönüp baktığınızda, başlangıçtaki o küçük adımları hatırlayacak ve ne kadar büyük bir yol kat ettiğinizi göreceksiniz. Bugün, hayatınızı değiştirecek olan başlangıçtır. Hedefinize ulaşmak için gösterdiğiniz çaba, sizi sadece başarılı bir kişi yapmakla kalmaz, aynı zamanda daha güçlü, daha dirençli ve daha bilge biri haline getirir. Buna inanarak adım atın ve her gün bir adım daha atmak için cesaret bulun. Hedefiniz ne olursa olsun, başarılı olmanın tek yolu, her zaman bir adım daha atmaktır. Çünkü başarı, kararlılıkla atılan her adımda gizlidir.', NULL, NULL, 'hedefim-2.jpg', '2025-01-09 19:25:41'),
(6, 'Hayallerin Peşine Düşmek: Bir Motivasyon Mektubu', 'Sevgili Dostum,\r\n\r\nBazen hayatta çıkışlar bulmak zor olabilir. Hedeflerimize ulaşmak için çabaladıkça engellerle karşılaşir, ümitsizlikle yüz yüe kalabiliriz. Ancak unutma, şu an hissettiğin tüm belirsizlikler ve zorluklar, seni büyüyen, güçlenen ve sonunda başarıya ulaşan biri yapacak.\r\n\r\nİlk adım, hayallerinin peşine düşmeye karar vermektir. Hayallerimiz, bizi biz yapan şeylerdir. Seni sabah yataktan kaldıran, gece boyunca hayalini kurduğun o hedefler… Onlara tutun. Bu yolda ilerlerken aklından asla çıkarma: Hayatın boyunca gerçekten değerli olan şeyler kolayca elde edilmez. Sabır, kararlılık ve cesaret seni bu yolculukta ileri taşıyacaktır.\r\n\r\nİkinci olarak, kendine karşı nazik olmalısın. Hayatın bazı dönemlerinde tüm kontrolün elinden kayıp gittiğini hissedebilirsin. Bu normaldir. Ancak unutma, sen bir insansın ve her insan hata yapar. Hatalar, bizim öğretmenlerimizdir. Onlardan ders al, ayağa kalk ve ilerlemeye devam et. Hedeflerin uğruna verdiğin her emek, seni daha bilge, daha güçlü bir birey haline getirecek.\r\n\r\nBaşarı yolunda en önemli aracın azimdir. Her gününü bir başlangıç olarak gör ve küçük adımlarla ilerle. Her ne kadar bazen bir yere varamadığını düşünsen de, unutma ki her adım seni hedeflerine bir adım daha yaklaştırıyor. Tıpkı bir heykeltıraşın mermere şekil vermesi gibi, sen de hayallerine şekil veriyorsun. Sabırla ve özenle.\r\n\r\nSana bir tavsiye daha: Çevreni özenle seç. Seni destekleyen, seni anlayan ve seni yüreklendiren insanlarla zaman geçir. Negatif düşünceler, hayallerine olan inancını sarsabilir. Pozitif bir çevre ise seni yukarı çeker ve seni potansiyelinin zirvesine taşır.\r\n\r\nVe unutma, bu yolculukta mental ve fiziksel sağlığına özen göstermek çok önemlidir. Düzenli egzersiz yap, dengeli beslen ve yeterince dinlen. Sağlıklı bir beden ve zihin, hedeflerine odaklanmanı ve önünü görmeni kolaylaştırır.\r\n\r\nSon sözüm: Hayallerin senden daha büyük değil. Onlar, senin gerçekleştirmeni bekleyen bir parçandır. Ne kadar büyük hayaller kurarsan, o kadar büyük adımlar atabilirsin. Hedeflerin ne kadar zor olursa olsun, unutma ki içinde bu hedeflere ulaşacak gücün var. Hayallerini gerçekleştirme yolunda ihtiyaç duyduğun tüm cesaret, azim ve gücü kendi içinde bulacaksın.\r\n\r\nBu yolda şimdiden başarılar dilerim. Senin başarı hikayeni duymak için sabırsızlanıyorum!\r\n\r\nSevgilerimizle,\r\n\r\nhedefim.com', NULL, NULL, 'hedefim-3.jpg', '2025-01-09 19:27:32'),
(7, 'HAYALLERİN PEŞİNE DÜŞMEK!..', '\r\n\r\nSevgili Dostum,\r\n\r\nHayat bir defalık bir yolculuk ve bu yolculuğun en değerli unsuru hayallerindir. Senin için, içinde bulunduğun bu an belki de bir dönüm noktası olabilir. Belki de şimdi, o uzun zamandır ertelediğin adımı atma zamanıdır.\r\n\r\nHayal kurmak cesaret ister. Ancak o hayalleri gerçeğe dönüştürmek daha büyük bir cesaret gerektirir. Senin bu cesareti gösterebileceğine yürekten inanıyorum. Hayatındaki hedeflere ulaşman için, her yeni günü bir fırsat olarak gör ve bu fırsatları en iyi şekilde değerlendirmek için çaba göster. \r\n\r\nUnutma, en büyük başarılar bile küçük bir adımla başlar. Küçük bir adım, zamanla büyük bir değişime dönüşebilir. Şu an karşılaştığın zorluklar seni yıldırmasın. Onlar sadece seni daha güçlü ve kararlı hale getiren duraklardır. Her zorluk, seni bir adım daha yukarı taşıyacak bir merdivendir.\r\n\r\nHayatın sunduğu engeller seni sınamak için değil, seni büyütmek içindir. Eğer şimdi mücadele ediyorsan, bu gelecekte başarının daha da anlamlı olacağı anlamına gelir. Asla unutma, mücadele ettiğin kadar güçleneceksin. Her şey senin içinde saklı. Şimdi bu potansiyeli açığa çıkarma zamanı!\r\n\r\nSen, hayallerinin peşinden koşmayı hak ediyorsun. Hayallerin, seni sen yapan en değerli şeylerden biridir. Korkularını ve şüphelerini bir kenara bırak ve kendi hikayeni yaz. Çünkü bu hayat senin ve onu nasıl yaşayacağına sadece sen karar verebilirsin.\r\n\r\nHayat bir maraton, bir sprint değil. Sabırlı ol, kendine inan ve asla vazgeçme. Çünkü seni bekleyen harika şeyler var. Sen bu yolda yalnız değilsin; yanında seni destekleyen insanlar, seni motive edecek kaynaklar hep var olacak.\r\n\r\nŞimdi kalk, harekete geç ve hayallerini gerçekleştirmek için ilk adımı at. Çünkü sen buna kesinlikle layıksın!\r\n\r\nSevgilerimizle,\r\n\r\nhedefim.com', NULL, NULL, 'hedefim-4.jpg', '2025-01-09 19:29:39');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `kullanicilar`
--
ALTER TABLE `kullanicilar`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `kullanici_adi` (`kullanici_adi`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Tablo için indeksler `tarifler`
--
ALTER TABLE `tarifler`
  ADD PRIMARY KEY (`id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `kullanicilar`
--
ALTER TABLE `kullanicilar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Tablo için AUTO_INCREMENT değeri `tarifler`
--
ALTER TABLE `tarifler`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
